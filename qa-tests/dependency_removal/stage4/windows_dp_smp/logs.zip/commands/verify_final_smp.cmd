@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\compiler\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\mkl\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%
call "C:\Program Files (x86)\Intel\oneAPI\mpi\2021.16\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set RAD_PYTHON_PATH=C:\Python\Python311\python311.dll
set I_MPI_FABRICS=shm
python qa-tests/dependency_removal/test_shared_result_sources.py
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_shared_results.py --engine exec/engine_win64.exe --output cbuild_dependency_stage4/queries-final --baseline cbuild_dependency_stage4/queries-before-verified
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_output_keywords.py --engine exec/engine_win64.exe --output cbuild_dependency_stage4/outputs-final --baseline cbuild_dependency_stage4/outputs-before
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_shared_results.py --engine exec/engine_win64.exe --output cbuild_dependency_stage4/h3d-final --baseline cbuild_dependency_stage4/h3d-before --h3d
exit /b %errorlevel%
