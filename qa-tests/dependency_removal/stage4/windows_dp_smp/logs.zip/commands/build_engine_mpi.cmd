@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\compiler\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\mkl\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%
call "C:\Program Files (x86)\Intel\oneAPI\mpi\2021.16\env\vars.bat" >nul
if errorlevel 1 exit /b 1
cmake -S engine -B engine/cbuild_engine_win64_impi_ninja -G Ninja -DVS_BUILD=1 -Darch=win64 -Dprecision=dp -Ddebug=0 -DEXEC_NAME=engine_win64_impi -DMPI=impi -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_Fortran_COMPILER="C:/Program Files (x86)/Intel/oneAPI/compiler/2025.2/bin/ifx.exe" -DCMAKE_C_COMPILER="C:/Program Files (x86)/Intel/oneAPI/compiler/2025.2/bin/icx.exe" -DCMAKE_CXX_COMPILER="C:/Program Files (x86)/Intel/oneAPI/compiler/2025.2/bin/icx.exe" -DCMAKE_CPP_COMPILER="C:/Program Files (x86)/Intel/oneAPI/compiler/2025.2/bin/icx.exe"
if errorlevel 1 exit /b 1
cmake --build engine/cbuild_engine_win64_impi_ninja --parallel 2
exit /b %errorlevel%
