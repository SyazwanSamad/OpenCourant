import hashlib
import json
from pathlib import Path
import shutil
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
raw = root / 'cbuild_dependency_stage6'
package = raw / 'package/OpenCourant'
report_path = raw / 'windows_package_manifest.json'
report = json.loads(report_path.read_text())
for row in report['files']:
    path = package / row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], row['path']
for folder in [package, raw / 'extracted-final/OpenCourant']:
    shutil.copy2(root / 'EXTLIB_VERSION.json', folder / 'licenses/EXTLIB_VERSION.json')
archive = raw / 'OpenCourant_win64.updated.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(package.rglob('*')):
        if path.is_file():
            z.write(path, 'OpenCourant/' + path.relative_to(package).as_posix())
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert z.read('OpenCourant/licenses/EXTLIB_VERSION.json') == (root / 'EXTLIB_VERSION.json').read_bytes()
archive.replace(raw / 'OpenCourant_win64.zip')
archive = raw / 'OpenCourant_win64.zip'
report.update(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), archive_bytes=archive.stat().st_size)
for row in report['files']:
    if row['path'] == 'licenses/EXTLIB_VERSION.json':
        path = package / row['path']
        row.update(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
report['only_repacked_change'] = 'licenses/EXTLIB_VERSION.json now points to the approved published fork; all other package bytes unchanged'
report_path.write_text(json.dumps(report, indent=2)+'\n')
runtime_path = raw / 'package_runtime_report.json'
runtime = json.loads(runtime_path.read_text())
runtime['final_package_archive_sha256'] = report['archive_sha256']
runtime['repacked_metadata_only'] = report['only_repacked_change']
runtime['runtime_binary_hashes'] = []
for row in report['files']:
    if row['path'] in ['exec/starter_win64.exe', 'exec/engine_win64.exe', 'exec/engine_win64_impi.exe', 'exec/open_reader_win64.dll']:
        path = raw / 'extracted-final/OpenCourant' / row['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        runtime['runtime_binary_hashes'].append(row)
runtime_path.write_text(json.dumps(runtime, indent=2)+'\n')
print('PASS final package pin updated; every executable, runtime, configuration and GUI byte unchanged')
