import ast
import json
from pathlib import Path
import re
import subprocess
import yaml

root = Path(__file__).resolve().parents[1]
raw = root / 'cbuild_dependency_stage6'
changed = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMR'], cwd=root, stderr=subprocess.DEVNULL).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root).decode().splitlines()
python_count = 0
for name in set(changed):
    path = root / name
    if path.suffix == '.py':
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=name)
        python_count += 1
json.loads((root / 'CMakeSettings.json').read_text())
json.loads((root / 'EXTLIB_VERSION.json').read_text())
workflows = {}
for path in (root / '.github/workflows').glob('*.yml'):
    workflows[path.name] = yaml.safe_load(path.read_text())
delivery = workflows['delivery_stable_ci.yml']
assert delivery['env']['TOOLS_REF'] == '1b6bb9200ee7dca899e61c18bd982c3fb1c72fd1'
bash = 'C:/Program Files/Git/usr/bin/bash.exe'
syntax = []
for job_name in ['package_windows', 'package_linuxa64', 'delivery']:
    job = delivery['jobs'][job_name]
    tools_checkout = next(step for step in job['steps'] if step.get('with', {}).get('repository') == 'OpenCourant/Tools')
    assert tools_checkout['with']['ref'] == '${{ env.TOOLS_REF }}'
    assert any('openreader_gui.patch' in step.get('run', '') for step in job['steps'])
    code = next(step['run'] for step in job['steps'] if step.get('name', '').startswith('Assemble'))
    assert 'check_package.py' in code and 'LICENSE.md' in code and 'EXTLIB_VERSION.json' in code
    path = raw / (job_name + '.bash')
    path.write_text(code, newline='\n')
    subprocess.run([bash, '-n', str(path)], check=True, capture_output=True)
    syntax.append(job_name)
pattern = re.search(r"grep -Eiq '([^']+)'", (root / 'containers/solver/Dockerfile').read_text())[1]
assert not re.search(pattern, 'OpenCourant/exec/libopen_reader_linux64.so', re.I)
for name in ['OpenCourant/extlib/h3d/lib/h3dwriter.dll', 'OpenCourant/exec/libhm_reader_linux64.so', 'OpenCourant/licenses/hm_reader_license.txt', 'OpenCourant/includes/h3dpublic_defs.h']:
    assert re.search(pattern, name, re.I), name
subprocess.run(['git', '-C', str(raw/'TOOLS'), 'apply', '--reverse', '--check', str(root/'Compiling_tools/patches/openreader_gui.patch')], check=True, capture_output=True)
for name in ['.github/workflows', 'Apptainer', 'containers', 'CMakeSettings.json', 'qa-tests/qa_tools', 'qa-tests/scripts']:
    path = root / name
    candidates = path.rglob('*') if path.is_dir() else [path]
    for candidate in candidates:
        if candidate.is_file() and candidate.suffix not in ['.png', '.pyc']:
            source = candidate.read_text(errors='replace')
            assert 'RAD_H3D_PATH' not in source and 'extlib/h3d' not in source and 'extlib\\h3d' not in source, candidate
result = subprocess.run(['git', 'diff', '--check'], cwd=root, capture_output=True, text=True)
assert result.returncode == 0, result.stdout
report = {'status': 'passed', 'changed_python_files_parsed': python_count,
          'workflows_parsed': len(workflows), 'release_assembly_bash_syntax_checked': syntax,
          'gui_patch_matches_pinned_source': True, 'docker_archive_guard_checked': True,
          'current_launcher_sdk_paths_absent': True, 'diff_check_passed': True}
(raw / 'static_checks.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
