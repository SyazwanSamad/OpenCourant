import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
work = root / 'cbuild_dependency_stage6/legacy-guard'
work.mkdir(exist_ok=True)
scripts = root / 'qa-tests/scripts'
env = dict(os.environ)
env['PATH'] = 'C:/Program Files/Git/usr/bin' + os.pathsep + env['PATH']
perl = 'C:/Program Files/Git/usr/bin/perl.exe'
for name in ['or_qa_script', 'or_radioss.pl', 'or_QA.constants']:
    shutil.copyfile(scripts / name, work / name)
(work / 'or_QA.files_all').write_text('h3dfiles retired.h3d\n')
run = subprocess.run([perl, './or_qa_script', str(root / 'exec/engine_win64.exe'), '--list_only'],
    cwd=work, env=env, capture_output=True, text=True, timeout=30)
output = run.stdout + run.stderr
(work / 'guard.log').write_text(output)
assert run.returncode != 0 and 'H3D QA extraction has been removed' in output, output[-3000:]
print(json.dumps({'status': 'passed', 'removed_qa_directive_exit_code': run.returncode}))
