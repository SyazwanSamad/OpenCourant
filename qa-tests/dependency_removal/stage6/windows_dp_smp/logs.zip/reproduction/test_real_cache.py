import contextlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import time

root = Path(__file__).resolve().parents[1]
raw = root / 'cbuild_dependency_stage6'
checkout = raw / 'cache-clean-verified'
checkout.mkdir(exist_ok=False)
manifest = json.loads((root / 'EXTLIB_VERSION.json').read_text())
manifest['url'] = (raw / 'extlib.zip').as_uri()
(checkout / 'EXTLIB_VERSION.json').write_text(json.dumps(manifest))
spec = importlib.util.spec_from_file_location('extlib_loader', root / 'Compiling_tools/script/load_extlib.py')
loader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loader)
loader.__file__ = str(checkout / 'Compiling_tools/script/load_extlib.py')
assert loader.main() == 0
assert loader.cache_ready(checkout / 'extlib', manifest)
assert loader.sha256_file(checkout / 'extlib.zip') == manifest['sha256']
assert loader.main() == 0
retired = checkout / 'extlib/h3d'
retired.mkdir()
(retired / 'h3dwriter.dll').write_text('fake stale SDK for negative cache test')
with contextlib.redirect_stderr(io.StringIO()) as error:
    refreshed = loader.main()
transient_error = error.getvalue()
if refreshed != 0:
    assert '[WinError 5]' in transient_error and retired.exists(), transient_error
    assert (checkout / 'extlib/.package-sha256').read_text().strip() == manifest['sha256']
    time.sleep(1)
    assert loader.main() == 0
assert not retired.exists()
sentinel = checkout / 'extlib/kept.txt'
sentinel.write_text('must survive a failed refresh')
manifest['sha256'] = '0' * 64
(checkout / 'EXTLIB_VERSION.json').write_text(json.dumps(manifest))
with contextlib.redirect_stderr(io.StringIO()) as error:
    assert loader.main() == 1
assert 'SHA-256 verification failed' in error.getvalue()
assert sentinel.read_text() == 'must survive a failed refresh'
assert not (checkout / 'extlib.zip.tmp').exists()
manifest['sha256'] = loader.sha256_file(raw / 'extlib.zip')
(checkout / 'EXTLIB_VERSION.json').write_text(json.dumps(manifest))
assert loader.cache_ready(checkout / 'extlib', manifest)
report = {'status': 'passed', 'source': 'Local file URI serving the exact new archive; public HTTP download awaits publication',
          'clean_install': True, 'cache_hit': True, 'stale_sdk_refreshed': True, 'failed_checksum_preserves_previous_cache': True,
          'archive_sha256': manifest['sha256'], 'installed_files': sum(p.is_file() for p in (checkout / 'extlib').rglob('*'))}
report['transient_windows_rename_error_preserved_cache'] = transient_error or None
(raw / 'real_cache_report.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS real archive: clean download/extraction, cache hit, stale SDK refresh, failed-refresh preservation')
