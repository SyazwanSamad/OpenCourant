@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python qa-tests/reader/rigid_parts/build_integration.py --starter-build cbuild_dependency_stage6/clean-starter --output cbuild_dependency_stage6/binaries
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/capture_baseline.py --binaries cbuild_dependency_stage6/binaries --starter-build cbuild_dependency_stage6/clean-starter --output cbuild_dependency_stage6/regression
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/compare_decks.py --binaries cbuild_dependency_stage6/binaries --output cbuild_dependency_stage6/native-decks
exit /b %errorlevel%
