# OpenReader dependency package v82-openreader-1

This package retains the open-source build dependencies from authenticated
upstream extlib v82. HM Reader, H3D Reader/Writer, their SDK headers/import
libraries and their limited-use notices are excluded. APR was private to the
removed reader and is also excluded. OpenReader itself is built from the solver
source and is not supplied as a vendor binary in this archive.

Boost, exprtk, LAPACK, metis, MD5 and zlib payloads are retained byte-for-byte.
All remaining open-source notices are preserved, including notices for code
used by the in-tree reader. Only the embedded package identity is rewritten.
There are 3,327 retained files. This is a dependency release, not a solver release.

`extlib.zip`: 26,112,105 bytes

SHA-256:
```
72831a1b3e95910e20e24cceb6fb6c4295cfab1fade01144f2cee53c603442a3
```

`extlib.manifest.json` records every retained file's size and SHA-256. The archive
is reproducible using `Compiling_tools/script/repack_extlib.py`; two independent
runs produced the same checksum. The authenticated source archive SHA-256 is
`2d0365018e67dd4813e6a2cf2ebf19d00d4771aa1aeb9b9706b7ea45fbb56982`.

Use this package with the OpenReader-only solver source. The validated loader
checks the pinned archive digest and identity, rejects retired and unsafe
entries, refreshes stale caches, and preserves the previous cache on a failed
refresh. Older HM Reader/H3D solver builds require their historical dependencies
and are not compatible with this package.
