import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'Compiling_tools/script'))
from load_extlib import forbidden_entry, sha256_file

source = root / 'cbuild_dependency_baseline_20261028/reference_binaries.zip'
assert source.resolve().is_relative_to(root)
target = source.with_suffix('.clean.zip')
removed = []
retained = []
before = sha256_file(source)
with ZipFile(source) as old, ZipFile(target, 'w', ZIP_DEFLATED, compresslevel=6) as clean:
    for entry in old.infolist():
        data = old.read(entry)
        row = {'path': entry.filename, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        if forbidden_entry(entry.filename):
            removed.append(row)
        else:
            clean.writestr(entry, data)
            retained.append(row)
with ZipFile(target) as clean:
    assert clean.testzip() is None
    for row in retained:
        assert hashlib.sha256(clean.read(row['path'])).hexdigest() == row['sha256']
    assert not any(forbidden_entry(name) for name in clean.namelist())
target.replace(source)
report = {'status': 'passed', 'path': source.relative_to(root).as_posix(), 'before_sha256': before,
          'after_sha256': sha256_file(source), 'removed_entries': removed,
          'retained_entries': retained, 'retained_bytes_unchanged': True,
          'note': 'The historical Stage 1 manifest retains the original archive digest as provenance; this ignored local archive has been sanitized in Stage 6.'}
(root / 'cbuild_dependency_stage6/reference_archive_cleanup.json').write_text(json.dumps(report, indent=2)+'\n')
print(f'PASS retired {len(removed)} SDK/APR/notice entries; retained {len(retained)} open-source executable entries byte-for-byte')
