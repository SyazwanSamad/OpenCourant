import ctypes
from ctypes import wintypes as w
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from zipfile import ZipFile
import numpy as np

root = Path(__file__).resolve().parents[1]
raw = root / 'cbuild_dependency_stage6'
package = raw / 'extracted-final/OpenCourant'
assert not package.exists(), 'Use a fresh extracted package'
with ZipFile(raw / 'OpenCourant_win64.zip') as archive:
    assert archive.testzip() is None
    archive.extractall(package.parent)
sys.path.insert(0, str(root / 'qa-tests/dependency_removal'))
sys.path.insert(0, str(root / 'Compiling_tools/script'))
from compare_decks import records
from load_extlib import forbidden_entry
from check_package import check_names

class ProcessEntry(ctypes.Structure):
    _fields_ = [('dwSize', w.DWORD), ('cntUsage', w.DWORD), ('th32ProcessID', w.DWORD),
        ('th32DefaultHeapID', ctypes.c_size_t), ('th32ModuleID', w.DWORD), ('cntThreads', w.DWORD),
        ('th32ParentProcessID', w.DWORD), ('pcPriClassBase', w.LONG), ('dwFlags', w.DWORD), ('szExeFile', w.WCHAR * 260)]

class ModuleEntry(ctypes.Structure):
    _fields_ = [('dwSize', w.DWORD), ('th32ModuleID', w.DWORD), ('th32ProcessID', w.DWORD),
        ('GlblcntUsage', w.DWORD), ('ProccntUsage', w.DWORD), ('modBaseAddr', ctypes.c_void_p),
        ('modBaseSize', w.DWORD), ('hModule', w.HMODULE), ('szModule', w.WCHAR * 256), ('szExePath', w.WCHAR * 260)]

k32 = ctypes.WinDLL('kernel32', use_last_error=True)
k32.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
k32.CreateToolhelp32Snapshot.restype = w.HANDLE
k32.CloseHandle.argtypes = [w.HANDLE]
for name, structure in [('Process32FirstW', ProcessEntry), ('Process32NextW', ProcessEntry),
                        ('Module32FirstW', ModuleEntry), ('Module32NextW', ModuleEntry)]:
    getattr(k32, name).argtypes = [w.HANDLE, ctypes.POINTER(structure)]
    getattr(k32, name).restype = w.BOOL

def snapshot(flags, pid, structure, first, following):
    handle = k32.CreateToolhelp32Snapshot(flags, pid)
    if handle == ctypes.c_void_p(-1).value:
        return []
    result = []
    entry = structure()
    entry.dwSize = ctypes.sizeof(entry)
    try:
        ok = getattr(k32, first)(handle, ctypes.byref(entry))
        while ok:
            result.append((entry.th32ProcessID, entry.th32ParentProcessID) if structure is ProcessEntry else entry.szExePath)
            ok = getattr(k32, following)(handle, ctypes.byref(entry))
    finally:
        k32.CloseHandle(handle)
    return result

env = {name: os.environ[name] for name in ['SystemRoot', 'WINDIR', 'TEMP', 'TMP', 'USERPROFILE', 'USERNAME', 'COMSPEC', 'PATHEXT', 'ALLUSERSPROFILE'] if name in os.environ}
runtime_bin = package / 'extlib/intelOneAPI_runtime/win64'
env.update(PATH=os.pathsep.join(map(str, [package/'exec', runtime_bin, Path(os.environ['SystemRoot'])/'System32', Path(os.environ['SystemRoot'])])),
    RAD_CFG_PATH=str(package/'hm_cfg_files'), OMP_NUM_THREADS='1', KMP_STACKSIZE='400m', I_MPI_FABRICS='shm')
module_reports = []

def run(command, folder, label, expected=0):
    modules = set()
    log = folder / (label + '.log')
    with log.open('w') as stream:
        process = subprocess.Popen(list(map(str, command)), cwd=folder, env=env, stdout=stream, stderr=subprocess.STDOUT)
        start = time.monotonic()
        descendants = {process.pid}
        while process.poll() is None:
            entries = snapshot(2, 0, ProcessEntry, 'Process32FirstW', 'Process32NextW')
            while True:
                previous_count = len(descendants)
                descendants.update(pid for pid, parent in entries if parent in descendants)
                if len(descendants) == previous_count:
                    break
            for pid in descendants:
                modules.update(snapshot(0x18, pid, ModuleEntry, 'Module32FirstW', 'Module32NextW'))
            if time.monotonic() - start > 180:
                process.kill()
                raise TimeoutError(label)
            time.sleep(0.01)
    output = log.read_text(errors='replace')
    assert process.returncode == expected, (label, process.returncode, output[-1500:])
    for name in modules:
        assert not forbidden_entry(name), name
        basename = Path(name).name.lower()
        if basename.startswith(('open_reader', 'libiomp', 'libmmd', 'svml_', 'mkl_', 'impi.', 'libfabric', 'libifcore', 'libifport')):
            assert Path(name).resolve().is_relative_to(package), name
    module_reports.append({'command': list(map(str, command)), 'exit_code': process.returncode, 'modules': sorted(modules)})
    return output

report = {'status': 'running', 'environment_path': env['PATH'], 'compiler_and_sdk_paths_absent': True,
          'cases': [], 'modules': module_reports}
try:
    with ZipFile(root/'qa-tests/dependency_removal/stage5/windows_dp_smp/native_mpi_values.zip') as baseline, \
         ZipFile(root/'qa-tests/dependency_removal/baseline/windows_dp_smp/histories.zip') as serial:
        for ranks in [1, 2]:
            for case, stem in [('accelerometer', 'ACCELERO'), ('friction', 'FRICT41')]:
                folder = raw / f'package-runtime-final/{case}-{ranks}'
                folder.mkdir(parents=True, exist_ok=False)
                prefix = f'native-mpi/{case}/'
                for name in baseline.namelist():
                    if name.startswith(prefix) and name.endswith(('.rad', '.inc')):
                        (folder/Path(name).name).write_bytes(baseline.read(name))
                output = run([package/'exec/starter_win64.exe', '-i', stem+'_0000.rad', '-np', ranks], folder, 'starter')
                assert '0 ERROR(S)' in output, output[-1000:]
                engine = package/'exec'/('engine_win64.exe' if ranks == 1 else 'engine_win64_impi.exe')
                command = [engine, '-i', stem+'_0001.rad', '-nt', '1']
                if ranks == 2:
                    command = [runtime_bin/'mpiexec.exe', '-localonly', '-n', '2', *command]
                output = run(command, folder, 'engine')
                assert 'NORMAL TERMINATION' in output
                widths, values = records(folder/(stem+'T01'))
                if ranks == 1:
                    reference = folder/'referenceT01'
                    reference.write_bytes(serial.read(f'{case}/v82/{stem}T01'))
                    old_widths, old_values = records(reference)
                else:
                    old = np.load(io.BytesIO(baseline.read(prefix+'values.npz')))
                    old_widths, old_values = old['widths'], old['histories']
                np.testing.assert_array_equal(widths, old_widths)
                np.testing.assert_allclose(values, old_values, rtol=1e-5, atol=1e-6)
                assert len(values) > 1 and values[-1, 0] > 0 and np.isfinite(values).all()
                np.savez_compressed(folder/'values.npz', widths=widths, histories=values)
                animations = sorted(folder.glob(stem+'A*.gz'))
                assert animations and not list(folder.glob('*.h3d'))
                if ranks == 2:
                    for path in animations:
                        assert gzip.decompress(path.read_bytes()) == gzip.decompress(baseline.read(prefix+path.name)), path.name
                report['cases'].append({'case': case, 'ranks': ranks, 'samples': len(values),
                    'max_history_difference': float(np.max(np.abs(values-old_values))),
                    'animation_files': len(animations), 'mpi_animation_bytes_match': True if ranks == 2 else None,
                    'inputs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix in ['.rad', '.inc']}})
                if case == 'friction' and ranks == 1:
                    animation = folder/'native.anim'
                    animation.write_bytes(gzip.decompress(animations[0].read_bytes()))
                    vtk = run([package/'exec/anim_to_vtk_win64.exe', animation.name], folder, 'vtk-converter')
                    assert '# vtk DataFile Version' in vtk and 'POINTS ' in vtk
                    run([package/'exec/th_to_csv_win64.exe', stem+'T01'], folder, 'csv-converter')
                    csv_files = list(folder.glob('*.csv'))
                    assert csv_files and all(path.stat().st_size > 0 for path in csv_files)
                    report['native_converters_passed'] = True
                    input_file = folder/(stem+'_0001.rad')
                    original = input_file.read_bytes()
                    input_file.write_bytes(original+b'\n/H3D/DT\n0 0.001\n')
                    (folder/'removed-output-request.rad').write_bytes(input_file.read_bytes())
                    try:
                        diagnostic = run([engine, '-i', input_file.name, '-nt', '1'], folder, 'retired-output', expected=2)
                    finally:
                        input_file.write_bytes(original)
                    assert 'H3D output has been removed' in diagnostic
                    report['removed_output_rejected'] = True
    assert any(Path(p).name.lower() == 'open_reader_win64.dll' for row in module_reports for p in row['modules'])
    assert any(Path(p).name.lower() == 'engine_win64_impi.exe' for row in module_reports for p in row['modules'])
    check_names({'OpenCourant/'+p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()}, 'win64')
    report['retired_dependency_modules_loaded'] = 0
    report['status'] = 'passed'
except Exception as error:
    report.update(status='failed', error=repr(error))
    raise
finally:
    (raw/'package_runtime_report.json').write_text(json.dumps(report, indent=2)+'\n')
print('PASS extracted Windows package: four physical SMP/MPI runs, exact histories, MPI animation bytes, converters, removed-output rejection and loaded modules')
