import importlib.util
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[1]
raw = root/'cbuild_dependency_stage6'
checkout = raw/'public-clean'
checkout.mkdir(exist_ok=False)
shutil.copy2(root/'EXTLIB_VERSION.json', checkout/'EXTLIB_VERSION.json')
spec = importlib.util.spec_from_file_location('loader', root/'Compiling_tools/script/load_extlib.py')
loader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loader)
loader.__file__ = str(checkout/'Compiling_tools/script/load_extlib.py')
assert loader.main() == 0
manifest = json.loads((checkout/'EXTLIB_VERSION.json').read_text())
assert loader.cache_ready(checkout/'extlib', manifest)
assert loader.sha256_file(checkout/'extlib.zip') == manifest['sha256']
assert not any(loader.forbidden_entry(path.relative_to(checkout/'extlib').as_posix()) for path in (checkout/'extlib').rglob('*'))
assert loader.main() == 0
report = {'status': 'passed', 'url': manifest['url'], 'sha256': manifest['sha256'],
          'unauthenticated_clean_download': True, 'identity_and_forbidden_entries_validated': True, 'subsequent_cache_hit': True}
(raw/'public_cache_report.json').write_text(json.dumps(report, indent=2)+'\n')
print('PASS public pin: unauthenticated clean download, SHA-256, extraction identity/absence and subsequent cache hit')
