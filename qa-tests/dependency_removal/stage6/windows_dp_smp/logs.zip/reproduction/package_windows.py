import hashlib
import json
from pathlib import Path
import shutil
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
raw = root / 'cbuild_dependency_stage6'
sys.path.insert(0, str(root / 'Compiling_tools/script'))
from check_package import check_names

package = raw / 'package/OpenCourant'
assert not package.exists(), 'Use a fresh package directory'
exe = package / 'exec'
exe.mkdir(parents=True)
for name in ['starter_win64.exe', 'open_reader_win64.dll', 'engine_win64.exe', 'engine_win64_impi.exe']:
    shutil.copy2(root / 'exec' / name, exe / name)
for path in (raw / 'TOOLS/exec').glob('*.exe'):
    shutil.copy2(path, exe / path.name)
for name in ['LICENSE.md', 'COPYRIGHT.md']:
    shutil.copy2(root / name, package / name)
shutil.copytree(root / 'hm_cfg_files', package / 'hm_cfg_files')
shutil.copytree(root / 'extlib/license', package / 'licenses')
shutil.copy2(root / 'EXTLIB_VERSION.json', package / 'licenses/EXTLIB_VERSION.json')
shutil.copytree(raw / 'TOOLS/openradioss_gui', package / 'openradioss_gui', ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(raw / 'TOOLS/input_converters/inp2rad/inp2rad/inp2rad.py', package / 'openradioss_gui/inp2rad.py')
oneapi = Path('C:/Program Files (x86)/Intel/oneAPI')
runtime = package / 'extlib/intelOneAPI_runtime'
runtime_bin = runtime / 'win64'
runtime_bin.mkdir(parents=True)
for component, version, files in [
    ('compiler', '2025.2', ['libiomp5md.dll', 'libmmd.dll', 'svml_dispmd.dll']),
    ('mkl', '2025.2', ['mkl_core.2.dll', 'mkl_def.2.dll', 'mkl_avx2.2.dll', 'mkl_avx512.2.dll', 'mkl_intel_thread.2.dll']),
    ('mpi', '2021.16', ['impi.dll', 'mpiexec.exe', 'hydra_service.exe', 'hydra_bstrap_proxy.exe', 'hydra_pmi_proxy.exe'])]:
    for name in files:
        shutil.copy2(oneapi / component / version / 'bin' / name, runtime_bin / name)
    for folder in (oneapi / component / version / 'share/doc').glob('*/licensing'):
        shutil.copytree(folder, runtime / 'license' / component / folder.parent.name, dirs_exist_ok=True)
for path in (oneapi / 'mpi/2021.16/opt/mpi/libfabric/bin').iterdir():
    if path.is_file():
        shutil.copy2(path, runtime_bin / path.name)
(runtime / 'license').mkdir(exist_ok=True)
(runtime / 'license/NOTICE.txt').write_text('Intel compiler/MKL/MPI runtime libraries, with their installed notices.\nhttps://www.intel.com/content/www/us/en/developer/articles/license/end-user-license-agreement.html\n')
names = {'OpenCourant/' + path.relative_to(package).as_posix() for path in package.rglob('*') if path.is_file()}
check_names(names, 'win64')
archive = raw / 'OpenCourant_win64.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(package.rglob('*')):
        if path.is_file():
            z.write(path, 'OpenCourant/' + path.relative_to(package).as_posix())
files = [{'path': path.relative_to(package).as_posix(), 'bytes': path.stat().st_size,
          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(package.rglob('*')) if path.is_file()]
report = {'status': 'passed', 'scope': 'Local Windows DP SMP/Intel MPI package assembled with oneAPI 2025.2 and Intel MPI 2021.16; GUI/converters from pinned Tools source. Hosted CI builds SP and additional release variants separately.',
          'tools_commit': '1b6bb9200ee7dca899e61c18bd982c3fb1c72fd1',
          'archive_bytes': archive.stat().st_size, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'files': files}
(raw / 'windows_package_manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'files': len(files), 'archive_bytes': report['archive_bytes']}))
