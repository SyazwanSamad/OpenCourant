@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
cmake -G Ninja -S starter -B cbuild_dependency_stage6/clean-starter -Darch=win64 -DEXEC_NAME=starter_win64 -Dprecision=dp -Ddebug=0 -DCMAKE_BUILD_TYPE=Release -DCMAKE_Fortran_COMPILER=ifx.exe -DCMAKE_C_COMPILER=icx.exe -DCMAKE_CXX_COMPILER=icx.exe -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
if errorlevel 1 exit /b 1
cmake --build cbuild_dependency_stage6/clean-starter --parallel 2
if errorlevel 1 exit /b 1
cmake --build engine/cbuild_engine_win64_ninja --parallel 2
if errorlevel 1 exit /b 1
cmake --build engine/cbuild_engine_win64_impi_ninja --parallel 2
exit /b %errorlevel%
