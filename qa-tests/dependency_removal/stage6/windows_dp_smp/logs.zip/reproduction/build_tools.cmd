@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
pushd cbuild_dependency_stage6\TOOLS\output_converters\anim_to_vtk\win64
call build.bat
if errorlevel 1 exit /b 1
popd
pushd cbuild_dependency_stage6\TOOLS\output_converters\th_to_csv\win64
call build.bat
if errorlevel 1 exit /b 1
popd
exit /b 0
