import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np

root=Path(__file__).resolve().parents[1]
raw=root/'cbuild_dependency_stage7'
sys.path.insert(0,str(root/'qa-tests/dependency_removal'))
from test_shared_results import run
from compare_decks import records
import os
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',KMP_STACKSIZE='400m',I_MPI_FABRICS='shm',RAD_CFG_PATH=str(root/'hm_cfg_files'))
before=raw/'pre-stage5'
source=root/'qa-tests/miniqa/RESTART/cra2/data'
report={'origin':'Preserved pre-Stage-5 GPL Windows DP Starter/OpenReader/Intel MPI Engine; no retired SDK installed or requested','binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in before.glob('*') if p.is_file()},'cases':[]}
with ZipFile(raw/'old_multidomain_checkpoints.zip','w',ZIP_DEFLATED) as archive:
 for ranks in [2,4]:
  folder=raw/f'old-multidomain-source/np{ranks}'
  shutil.copytree(source,folder)
  deck=folder/'CRA2V44_0003.rad'
  text=(folder/'CRA2V44_0002.rad').read_text().replace('/RUN/CRA2V44/2','/RUN/CRA2V44/3')
  text=re.sub(r'(/RUN/CRA2V44/3\n)\s*5\n',r'\g<1>                 7.5\n',text)
  assert '/RUN/CRA2V44/3\n                 7.5\n' in text
  deck.write_text(text)
  run([before/'starter_win64.exe','-i','CRA2V44_0000.rad','-np',ranks],folder,env)
  out=run(['mpiexec','-localonly','-n',ranks,before/'engine_win64_impi.exe','-i','CRA2V44_0001.rad','-nt','1'],folder,env)
  assert 'NORMAL TERMINATION' in out
  rst=sorted(folder.glob('CRA2V44_0001_*.rst'));assert len(rst)==ranks
  for path in rst:
   archive.write(path,f'np{ranks}/{path.name}')
  for segment in [2,3]:
   name=f'CRA2V44_{segment:04}.rad'
   archive.write(folder/name,f'np{ranks}/{name}')
   out=run(['mpiexec','-localonly','-n',ranks,before/'engine_win64_impi.exe','-i',name,'-nt','1'],folder,env)
   assert 'NORMAL TERMINATION' in out
   widths,values=records(folder/f'CRA2V44T{segment:02}')
   assert np.isfinite(values).all() and len(values)>1
   path=folder/f'reference{segment}.npz';np.savez_compressed(path,widths=widths,values=values)
   archive.write(path,f'np{ranks}/{path.name}')
   report['cases'].append({'ranks':ranks,'segment':segment,'samples':len(values),'final_time':float(values[-1,0])})
   print(report['cases'][-1],flush=True)
 archive.writestr('provenance.json',json.dumps(report,indent=2)+'\n')
(raw/'old_multidomain_provenance.json').write_text(json.dumps(report,indent=2)+'\n')
