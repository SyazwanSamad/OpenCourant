@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
set RAD_CFG_PATH=C:\Programming\OpenCourant\hm_cfg_files
set OMP_STACKSIZE=400m
set KMP_STACKSIZE=400m
cmake -S qa-tests -B qa-tests/ctest_stage7_dp_smp_complete -Darch=win64 -DPREC=dp -DMPI=smp -DNP=1 -DNT=2 -DSTDOUT=1 -DKEEP=1 -DDEBUG=optimized -Dtype=default -Dpon_run=1x2
if errorlevel 1 exit /b 1
ctest --test-dir qa-tests/ctest_stage7_dp_smp_complete -C Release --output-on-failure --timeout 600 -j 2 --output-junit C:/Programming/OpenCourant/cbuild_dependency_stage7/miniqa_dp_smp_complete.xml > cbuild_dependency_stage7/miniqa-dp-smp-complete.log 2>&1
set SMP_STATUS=%errorlevel%
cmake -S qa-tests -B qa-tests/ctest_stage7_dp_pon_extra -Darch=win64 -DPREC=dp -DMPI=impi -DNP=4 -DNT=1 -DSTDOUT=1 -DKEEP=1 -DDEBUG=optimized -Dtype=pon -Dpon_run=1x4,2x2,4x1
if errorlevel 1 exit /b 1
ctest --test-dir qa-tests/ctest_stage7_dp_pon_extra -C Release --output-on-failure --timeout 600 -j 2 -R "^1\.(89|90|91)$" --output-junit C:/Programming/OpenCourant/cbuild_dependency_stage7/miniqa_dp_pon_extra.xml > cbuild_dependency_stage7/miniqa-dp-pon-extra.log 2>&1
set PON_STATUS=%errorlevel%
echo SMP_STATUS=%SMP_STATUS% PON_EXTRA_STATUS=%PON_STATUS%
if not %SMP_STATUS%==0 exit /b 1
exit /b %PON_STATUS%
