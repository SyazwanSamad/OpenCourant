import concurrent.futures as F
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
raw=root/'cbuild_dependency_stage7'
before=raw/'pre-stage5'
shutil.copy2(root/'cbuild_dependency_stage5/before-engine_win64_impi.exe',before/'engine_win64_impi.exe')
work=root/'qa-tests/ctest_stage7_dp_pon_before_extra'
work.mkdir(exist_ok=False)
registration=(root/'qa-tests/qa_tools/miniqa.txt').read_text()
failed=['1.89','1.90','1.91']

def run(test):
    deck=re.search(r'NAME '+re.escape(test)+r' COMMAND .*?-deck_dir (\S+)',registration)[1]
    command=[sys.executable,str(root/'qa-tests/qa_tools/or_execute.py'),'-deck_dir',deck,'-test_id',test,'-arch','win64','-mpi','impi','-prec','dp','-np','4','-nt','1','-stdout','0','-keep','1','-qa_type','pon','-pon_string','1x4,2x2,4x1','-starter',str(before/'starter_win64'),'-engine',str(before/'engine_win64_impi')]
    result=subprocess.run(command,cwd=work,capture_output=True,text=True,timeout=600)
    (raw/f'pon-before-extra-{test}.log').write_text(result.stdout+result.stderr)
    checksums=re.findall(r'Parse (\S+), Checksum: (\S+)',result.stdout)
    row={'test':test,'deck':deck,'exit_code':result.returncode,'checksums':checksums,'command':command}
    print(test,result.returncode,checksums,flush=True)
    return row
with F.ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(run,failed))
(raw/'pon_pre_stage5_extra.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==3
assert all(len(row['checksums'])==3 for row in rows)
