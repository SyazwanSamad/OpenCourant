@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python cbuild_dependency_stage7/package_windows.py > cbuild_dependency_stage7/package-build.log 2>&1
if errorlevel 1 exit /b 1
python Compiling_tools/script/check_package.py cbuild_dependency_stage7/OpenCourant_win64.zip --arch win64 > cbuild_dependency_stage7/package-check.log 2>&1
if errorlevel 1 exit /b 1
python cbuild_dependency_stage7/check_runtime_package_dp.py > cbuild_dependency_stage7/package-runtime-dp.log 2>&1
if errorlevel 1 exit /b 1
python cbuild_dependency_stage7/check_runtime_package_sp.py > cbuild_dependency_stage7/package-runtime-sp.log 2>&1
exit /b %errorlevel%
