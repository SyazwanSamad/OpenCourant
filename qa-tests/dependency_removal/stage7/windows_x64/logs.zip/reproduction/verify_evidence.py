import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1]
base = root/'qa-tests/dependency_removal'
counts = {'manifests': 0, 'evidence_files_hashed': 0, 'zip_archives_crc_checked': 0, 'text_entries_scanned': 0, 'source_files_hashed': 0, 'documentation_links_checked': 0}
excluded = re.compile(rb'(?i)\br66\b|openreader_r66')
text_suffixes = ('.json', '.md', '.txt', '.log', '.rad', '.inc', '.cmd', '.html', '.report')

def check_text(data, label):
    assert not excluded.search(data), 'Excluded one-time model reference: ' + label
    counts['text_entries_scanned'] += 1

for path in base.glob('**/manifest.json'):
    data = json.loads(path.read_text())
    counts['manifests'] += 1
    for row in data['files']:
        target = path.parent/row['path']
        blob = target.read_bytes()
        assert len(blob) == row['bytes'] and hashlib.sha256(blob).hexdigest() == row['sha256'], target
        counts['evidence_files_hashed'] += 1
    for entry in path.parent.iterdir():
        if entry.suffix == '.zip':
            with ZipFile(entry) as archive:
                assert archive.testzip() is None, entry
                for name in archive.namelist():
                    assert not excluded.search(name.encode()), entry
                    if name.lower().endswith(text_suffixes):
                        check_text(archive.read(name), entry.name+':'+name)
            counts['zip_archives_crc_checked'] += 1
        elif entry.name.endswith('.json.gz'):
            blob = gzip.decompress(entry.read_bytes())
            json.loads(blob)
            check_text(blob, entry.name)
        elif entry.name.endswith(text_suffixes):
            check_text(entry.read_bytes(), entry.name)

current = base/'stage7/windows_x64'
for row in json.loads((current/'source_manifest.json').read_text()):
    blob = (root/row['path']).read_bytes()
    assert len(blob) == row['bytes'] and hashlib.sha256(blob).hexdigest() == row['sha256'], row['path']
    counts['source_files_hashed'] += 1

for name in ['qa-tests/dependency_removal/STAGE7.md', 'qa-tests/dependency_removal/STAGE6.md', 'qa-tests/reader/README.md', 'doc/Remove_HMReader_H3D_plan.md', 'doc/OpenReader_implementation_plan.md']:
    path = root/name
    source = path.read_bytes()
    check_text(source, name)
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', source.decode()):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        target = unquote(target.split('#', 1)[0].strip('<>'))
        resolved = root/target.lstrip('/') if target.startswith('/') else path.parent/target
        assert resolved.exists(), (name, target)
        counts['documentation_links_checked'] += 1

result = subprocess.run(['git', 'diff', '--check'], cwd=root, capture_output=True, text=True)
assert result.returncode == 0, result.stdout
new_paths = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root).decode().splitlines()
for name in new_paths:
    if name == 'AGENTS.md' or name.startswith(('qa-tests/dependency_removal/stage6/', 'qa-tests/dependency_removal/stage7/')):
        continue
    result = subprocess.run(['git', 'diff', '--no-index', '--check', '--', '/dev/null', name], cwd=root, capture_output=True, text=True)
    assert result.returncode in (0, 1) and not result.stdout, (name, result.stdout, result.stderr)
gate = json.loads((current/'gate_report.json').read_text())
assert gate['status'] == 'failed' and not gate['release_approved']
report = {'status': 'passed', **counts, 'historical_evidence_files_unchanged': True,
          'current_source_snapshot_matches': True, 'tracked_and_new_file_whitespace_checks_passed': True,
          'excluded_one_time_model_references': 0, 'failed_gate_preserved': True}
(root/'cbuild_dependency_stage7/evidence_integrity.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
