@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_old_multidomain.py --engine exec/engine_win64_impi.exe --output cbuild_dependency_stage7/old-multidomain-current
exit /b %errorlevel%
