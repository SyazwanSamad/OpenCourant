import json
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1]
pattern = re.compile(r'(?i)^(?:lib)?(?:hm_reader|h3dreader|h3dwriter).*\.(?:dll|lib|so(?:\.\d+)*)$|^h3dpublic.*\.h$|^h3d_values\.h$')
paths = subprocess.check_output(['rg', '--files', '--hidden', '--no-ignore', '-g', '!**/.git/**', '--iglob', '*.zip', '--iglob', '*hm_reader*', '--iglob', '*h3d*'], cwd=root).decode().splitlines()
live = []
archives = []
for name in paths:
    path = root / name
    if path.suffix.lower() == '.zip':
        with ZipFile(path) as archive:
            found = [entry for entry in archive.namelist() if pattern.search(Path(entry).name)]
        if found:
            archives.append({'path': name, 'entries': found})
    elif pattern.search(path.name):
        live.append(name)
assert not live and not archives, (live, archives)
assert not (root / 'extlib/h3d').exists()
assert not (root / 'extlib/hm_reader').exists()
assert not (root / 'cbuild_dependency_stage3/reference_payload').exists()
result = {'status': 'passed', 'ignored_workspace_sdk_files': live, 'archives_with_sdk_payloads': archives,
          'zip_archives_inspected': sum(name.endswith('.zip') for name in paths),
          'scope': 'SDK binaries, import libraries and public headers by filename across tracked and ignored workspace files/ZIP entries; historical source, output data and textual provenance retained'}
(root / 'cbuild_dependency_stage7/payload_absence.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
