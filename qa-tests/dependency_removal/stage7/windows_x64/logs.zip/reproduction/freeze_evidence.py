import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT/'cbuild_dependency_stage7'
DEST = ROOT/'qa-tests/dependency_removal/stage7/windows_x64'
DEST.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


def record(path, base):
    data = path.read_bytes()
    return {'path': path.relative_to(base).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, stderr=subprocess.DEVNULL).decode().strip()


gate = read(RAW/'gate_report.json')
assert gate['status'] == 'failed' and not gate['release_approved']
assert [s['passed'] for s in gate['suites']] == [79, 79, 72, 72, 62, 1]
suite = read(RAW/'regression/report.json')
assert suite['status'] == 'passed' and sum(r['pass_lines'] for r in suite['runs']) == 149
for precision in ['dp', 'sp']:
    runtime = read(RAW/f'package_runtime_{precision}_report.json')
    assert runtime['status'] == 'passed' and len(runtime['cases']) == 4
    assert len(runtime['modules']) == 11 and runtime['retired_dependency_modules_loaded'] == 0
    assert all(r['max_history_difference'] == 0 for r in runtime['cases'])
    assert read(RAW/f'removed-{precision}/report.json')['status'] == 'passed'
assert read(RAW/'old-multidomain-current/report.json')['status'] == 'passed'

reports = {'gate_report.json': 'gate_report.json', 'reader_suite_report.json': 'regression/report.json',
    'numerical_report.json': 'regression/numerical/report.json',
    'mode2_report.json': 'regression/mode2-numerical/report.json',
    'native_models_report.json': 'native-decks/report.json',
    'old_serial_report.json': 'old-checkpoints-dp/report.json',
    'old_multidomain_report.json': 'old-multidomain-current/report.json',
    'old_multidomain_provenance.json': 'old_multidomain_provenance.json',
    'native_output_report.json': 'native-output-dp-final/report.json',
    'removed_output_dp_report.json': 'removed-dp/report.json',
    'removed_output_sp_report.json': 'removed-sp/report.json',
    'package_runtime_dp_report.json': 'package_runtime_dp_report.json',
    'package_runtime_sp_report.json': 'package_runtime_sp_report.json',
    'binary_audit.json': 'binary_audit.json', 'static_checks.json': 'static_checks.json',
    'copyright_audit.json': 'copyright_audit.json',
    'law13_diagnosis.json': 'law13_diagnosis.json',
    'pon_pre_stage5.json': 'pon_pre_stage5.json', 'pon_pre_stage5_extra.json': 'pon_pre_stage5_extra.json',
    'pon_cross_version_comparison.json': 'pon_cross_version_comparison.json',
    'pon_extra_cross_version_comparison.json': 'pon_extra_cross_version_comparison.json'}
for name, source in reports.items():
    shutil.copyfile(RAW/source, DEST/name)
for name in ['windows_package_manifest.json', 'regression/input_manifest.json',
             'regression/generated_input_manifest.json']:
    (DEST/(Path(name).name+'.gz')).write_bytes(gzip.compress((RAW/name).read_bytes(), mtime=0))

inputs = set()
for folder in re.findall(r'-deck_dir (\S+)', (ROOT/'qa-tests/qa_tools/miniqa.txt').read_text()):
    inputs.update(path for path in (ROOT/'qa-tests'/folder/'data').rglob('*') if path.is_file())
write(DEST/'miniqa_input_manifest.json', [record(p, ROOT) for p in sorted(inputs)])

with ZipFile(DEST/'logs.zip', 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(RAW.glob('*.log')):
        archive.write(path, path.name)
    for path in sorted(RAW.glob('*.pe.log')):
        if path.name not in archive.namelist():
            archive.write(path, path.name)
    for name in ['regression', 'native-decks', 'removed-dp', 'removed-sp', 'old-checkpoints-dp',
                 'old-multidomain-current', 'old-multidomain-source', 'native-output-dp-final',
                 'package-runtime-final', 'package-runtime-sp', 'sp-runtime-reference']:
        for path in sorted((RAW/name).rglob('*.log')):
            archive.write(path, path.relative_to(RAW).as_posix())
    for path in sorted(RAW.glob('*')):
        if path.suffix in ['.py', '.cmd']:
            archive.write(path, 'reproduction/'+path.name)
    archive.write(ROOT/'cbuild_dependency_stage4/runtime_prefix.cmd', 'reproduction/runtime_prefix.cmd')

with ZipFile(DEST/'miniqa_results.zip', 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(RAW.glob('miniqa*.xml')):
        archive.write(path, path.name)
    for name in ['miniqa_dp_smp_complete', 'miniqa_dp_mpi_final', 'miniqa_sp_smp', 'miniqa_sp_mpi',
                 'miniqa_dp_pon', 'miniqa_dp_pon_extra']:
        import xml.etree.ElementTree as ET
        tree = ET.parse(RAW/(name+'.xml')).getroot()
        folder = ROOT/'qa-tests'/('ctest_stage7_'+name.removeprefix('miniqa_'))
        for test in tree.findall('testcase'):
            if test.find('failure') is None:
                continue
            suffix = '_'+test.attrib['name']
            for case in folder.glob('run_*'):
                if not case.name.endswith(suffix):
                    continue
                for path in sorted(case.iterdir()):
                    if path.is_file() and (path.suffix in ['.rad', '.inc', '.out', '.log', '.txt']):
                        archive.write(path, path.relative_to(ROOT/'qa-tests').as_posix())
    # Keep all old/current layout listings, including JUnit's truncated heavy case.
    for work in ['ctest_stage7_dp_pon_before_final', 'ctest_stage7_dp_pon_before_extra']:
        for path in sorted((ROOT/'qa-tests'/work).glob('run_*/*.out_*x*.txt')):
            archive.write(path, path.relative_to(ROOT/'qa-tests').as_posix())

with ZipFile(DEST/'numerical_values.zip', 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for name in ['regression', 'native-decks', 'removed-dp', 'removed-sp', 'old-checkpoints-dp',
                 'old-multidomain-current', 'native-output-dp-final', 'package-runtime-final',
                 'package-runtime-sp']:
        for path in sorted((RAW/name).rglob('*')):
            if path.is_file() and path.suffix in ['.npz', '.rad', '.inc', '.json', '.csv']:
                archive.write(path, path.relative_to(RAW).as_posix())
    for name in ['law13-current-current', 'law13-current-pre-stage5',
                 'law13-pre-stage5-current', 'law13-pre-stage5-pre-stage5']:
        for path in sorted((RAW/name).glob('*')):
            if path.is_file() and path.suffix in ['.rad', '.inc', '.out', '.log']:
                archive.write(path, path.relative_to(RAW).as_posix())

audit = read(RAW/'binary_audit.json')
assert len(audit['binaries']) == 7 and len(audit['build_graphs']) == 6
with ZipFile(DEST/'build_settings.zip', 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for row in audit['build_graphs']:
        path = ROOT/row['path']
        assert record(path, ROOT)['sha256'] == row['sha256']
        archive.write(path, row['path'])
        archive.write(path.parent/'CMakeCache.txt', str(Path(row['path']).parent/'CMakeCache.txt'))
for row in audit['binaries']:
    assert record(ROOT/row['path'], ROOT)['sha256'] == row['sha256']

paths = set(git('diff', '--name-only', '--diff-filter=ACMRT').splitlines())
paths.update(git('ls-files', '--others', '--exclude-standard').splitlines())
paths = sorted(name for name in paths if (ROOT/name).is_file() and name != 'AGENTS.md'
    and not re.match(r'qa-tests/dependency_removal/(?:baseline|stage\d+)/', name))
write(DEST/'source_manifest.json', [record(ROOT/name, ROOT) for name in paths])
with ZipFile(DEST/'source_snapshot.zip', 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for name in paths:
        archive.write(ROOT/name, name)

subprocess.run([__import__('sys').executable, str(RAW/'scan_payloads.py')], cwd=ROOT, check=True,
               stdout=subprocess.DEVNULL)
shutil.copyfile(RAW/'payload_absence.json', DEST/'payload_absence.json')
files = [record(path, DEST) for path in sorted(DEST.iterdir()) if path.is_file() and path.name != 'manifest.json']
manifest = {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'failed', 'release_approved': False, 'platform': 'Windows x64',
    'deferred_at_user_request': ['Linux x64', 'Linux ARM64'],
    'base_commit': git('rev-parse', 'HEAD'), 'branch': git('branch', '--show-current'),
    'working_tree_dirty': True, 'binaries': audit['binaries'], 'files': files}
write(DEST/'manifest.json', manifest)
print('Frozen Windows Stage 7 evidence:', len(files), 'files; release gate failed')
