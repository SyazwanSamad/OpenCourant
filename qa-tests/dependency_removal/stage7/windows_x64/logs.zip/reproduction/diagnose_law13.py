import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
raw = root/'cbuild_dependency_stage7'
reference = raw/'pre-stage5'
reference.mkdir(exist_ok=True)
for name in ['starter_win64.exe','engine_win64.exe','open_reader_win64.dll']:
    shutil.copy2(root/'cbuild_dependency_stage5'/('before-'+name),reference/name)
source = root/'qa-tests/miniqa/LOIS/LOI13/solide/data'
report = []
env = dict(os.environ, RAD_CFG_PATH=str(root/'hm_cfg_files'), OMP_NUM_THREADS='2', KMP_STACKSIZE='400m')
for starter in ['current','pre-stage5']:
    for engine in ['current','pre-stage5']:
        work = raw/f'law13-{starter}-{engine}'
        shutil.copytree(source,work)
        executables = [root/'exec/starter_win64.exe' if starter=='current' else reference/'starter_win64.exe',
                       root/'exec/engine_win64.exe' if engine=='current' else reference/'engine_win64.exe']
        row = {'starter':starter,'engine':engine}
        for executable, filename, kind in zip(executables,['MODELE_0000.rad','MODELE_0001.rad'],['starter','engine']):
            command=[str(executable),'-i',filename,'-np','1'] if kind=='starter' else [str(executable),'-i',filename,'-nt','2']
            result=subprocess.run(command,cwd=work,env=env,capture_output=True,text=True,errors='replace',timeout=60)
            (work/(kind+'.log')).write_text(result.stdout+result.stderr)
            row[kind+'_exit']=result.returncode
            assert result.returncode==0,(row,(result.stdout+result.stderr)[-1200:])
        data=(work/'MODELE_0001.out').read_text()
        row['nan_in_listing']='NaN' in data
        row['normal']='NORMAL TERMINATION' in data
        report.append(row)
(raw/'law13_diagnosis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
