@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
cmake -G Ninja -S engine -B cbuild_dependency_stage7/engine-sp -Darch=win64 -DEXEC_NAME=engine_win64_sp -Dprecision=sp -Ddebug=0 -DMPI=smp -DCMAKE_BUILD_TYPE=Release -DCMAKE_Fortran_COMPILER=ifx.exe -DCMAKE_C_COMPILER=icx.exe -DCMAKE_CXX_COMPILER=icx.exe -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
if errorlevel 1 exit /b 1
cmake --build cbuild_dependency_stage7/engine-sp --parallel 3
exit /b %errorlevel%
