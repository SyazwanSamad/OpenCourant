@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
set RAD_CFG_PATH=C:\Programming\OpenCourant\hm_cfg_files
set OMP_STACKSIZE=400m
set KMP_STACKSIZE=400m
cmake -S qa-tests -B qa-tests/ctest_stage7_sp_smp -Darch=win64 -DPREC=sp -DMPI=smp -DNP=1 -DNT=2 -DSTDOUT=1 -DKEEP=1 -DDEBUG=optimized -Dtype=default -Dpon_run=1x2
if errorlevel 1 exit /b 1
ctest --test-dir qa-tests/ctest_stage7_sp_smp -C Release --output-on-failure --timeout 600 -j 2 --output-junit C:/Programming/OpenCourant/cbuild_dependency_stage7/miniqa_sp_smp.xml > cbuild_dependency_stage7/miniqa-sp-smp.log 2>&1
set SMP_STATUS=%errorlevel%
cmake -S qa-tests -B qa-tests/ctest_stage7_sp_mpi -Darch=win64 -DPREC=sp -DMPI=impi -DNP=2 -DNT=2 -DSTDOUT=1 -DKEEP=1 -DDEBUG=optimized -Dtype=default -Dpon_run=2x2
if errorlevel 1 exit /b 1
ctest --test-dir qa-tests/ctest_stage7_sp_mpi -C Release --output-on-failure --timeout 600 -j 2 --output-junit C:/Programming/OpenCourant/cbuild_dependency_stage7/miniqa_sp_mpi.xml > cbuild_dependency_stage7/miniqa-sp-mpi.log 2>&1
set MPI_STATUS=%errorlevel%
python qa-tests/dependency_removal/test_removed_output.py --starter exec/starter_win64_sp.exe --engine exec/engine_win64_sp.exe --output cbuild_dependency_stage7/removed-sp > cbuild_dependency_stage7/removed-sp.log 2>&1
set REMOVED_STATUS=%errorlevel%
echo SP_SMP_STATUS=%SMP_STATUS% SP_MPI_STATUS=%MPI_STATUS% REMOVED_STATUS=%REMOVED_STATUS%
if not %SMP_STATUS%==0 exit /b 1
if not %MPI_STATUS%==0 exit /b 1
exit /b %REMOVED_STATUS%
