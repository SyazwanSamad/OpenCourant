import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
raw=root/'cbuild_dependency_stage7'
suites=[]
for name,precision,layout in [('miniqa_dp_smp_complete','dp','1 MPI rank x 2 OpenMP threads'),('miniqa_dp_mpi_final','dp','2 MPI ranks x 2 OpenMP threads'),('miniqa_sp_smp','sp','1 MPI rank x 2 OpenMP threads'),('miniqa_sp_mpi','sp','2 MPI ranks x 2 OpenMP threads'),('miniqa_dp_pon','dp','1x4, 2x2, 4x1'),('miniqa_dp_pon_extra','dp','1x4, 2x2, 4x1')]:
 tree=ET.parse(raw/(name+'.xml')).getroot()
 cases=tree.findall('testcase');failed=[];skipped=[]
 for case in cases:
  if case.find('failure') is not None:
   failed.append(case.attrib['name'])
  if 'Skiping' in case.findtext('system-out',''):
   skipped.append(case.attrib['name'])
 suites.append({'suite':name,'precision':precision,'layout':layout,'registered':len(cases),'passed':len(cases)-len(failed)-len(skipped),'skipped':skipped,'failed':failed,'seconds':float(tree.attrib['time'])})
assert all(s['registered']==81 for s in suites[:4])
assert sum(s['registered'] for s in suites[4:])==81
report={'status':'failed','release_approved':False,'platform':'Windows x64','deferred_at_user_request':['Linux x64','Linux ARM64'],'suites':suites,'reference_values_regenerated':False,'tolerances_widened':False,'legacy_TYPE25_rules_carried_verbatim_to_CTest':True,'unverified_Windows_workflows':['R2R external coupling','implicit/modal execution','external user-library/coupled execution','large-model performance'],'legacy_keyword_findings':[{'keyword':'/MAT/LAW13','obsolete_since':'v13.0','upstream_policy':'Supported but no longer maintained','classification':'Pre-existing legacy compatibility failure; test retained','source':'https://help.altair.com/hwsolvers/rad/topics/solvers/rad/obsolete_overview_starter_r.htm'}],'notes':['PON checksum failures are reproduced with preserved pre-Stage-5 binaries.','LAW13 NaN is reproduced with every current/pre-Stage-5 Starter and Engine pairing.','A near-zero DP mass-error value fails the existing Python zero/relative tolerance rules; no tolerance was changed.']}
(raw/'gate_report.json').write_text(json.dumps(report,indent=2)+'\n')
for row in suites:
 print(row['suite'],row['passed'],'passed',len(row['skipped']),'skipped',len(row['failed']),'failed',row['failed'])
