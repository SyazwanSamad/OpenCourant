@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
cmake -G Ninja -S starter -B cbuild_dependency_stage7/starter-sp -Darch=win64 -DEXEC_NAME=starter_win64_sp -Dprecision=sp -Ddebug=0 -DCMAKE_BUILD_TYPE=Release -DCMAKE_Fortran_COMPILER=ifx.exe -DCMAKE_C_COMPILER=icx.exe -DCMAKE_CXX_COMPILER=icx.exe -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
if errorlevel 1 exit /b 1
cmake --build cbuild_dependency_stage7/starter-sp --parallel 4
exit /b %errorlevel%
