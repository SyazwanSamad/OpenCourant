@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python cbuild_dependency_stage7/diagnose_pon_extra.py
exit /b %errorlevel%
