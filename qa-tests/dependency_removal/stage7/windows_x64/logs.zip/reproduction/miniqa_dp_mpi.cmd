@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
set RAD_CFG_PATH=C:\Programming\OpenCourant\hm_cfg_files
set OMP_STACKSIZE=400m
set KMP_STACKSIZE=400m
cmake -S qa-tests -B qa-tests/ctest_stage7_dp_mpi -Darch=win64 -DPREC=dp -DMPI=impi -DNP=2 -DNT=2 -DSTDOUT=1 -DKEEP=1 -DDEBUG=optimized -Dtype=default -Dpon_run=2x2
if errorlevel 1 exit /b 1
ctest --test-dir qa-tests/ctest_stage7_dp_mpi -C Release --output-on-failure --timeout 600 -j 2 --output-junit C:/Programming/OpenCourant/cbuild_dependency_stage7/miniqa_dp_mpi.xml
exit /b %errorlevel%
