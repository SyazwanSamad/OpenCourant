@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_qa_comparison.py
if errorlevel 1 exit /b 1
python qa-tests/reader/rigid_parts/build_integration.py --starter-build cbuild_dependency_stage6/clean-starter --output cbuild_dependency_stage7/binaries
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/capture_baseline.py --binaries cbuild_dependency_stage7/binaries --starter-build cbuild_dependency_stage6/clean-starter --output cbuild_dependency_stage7/regression
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/compare_decks.py --binaries cbuild_dependency_stage7/binaries --output cbuild_dependency_stage7/native-decks
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_removed_output.py --engine exec/engine_win64.exe --output cbuild_dependency_stage7/removed-dp
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_old_checkpoints.py --engine exec/engine_win64.exe --output cbuild_dependency_stage7/old-checkpoints-dp
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_output_keywords.py --engine exec/engine_win64.exe --output cbuild_dependency_stage7/native-output-dp --baseline cbuild_dependency_stage5/output
exit /b %errorlevel%
