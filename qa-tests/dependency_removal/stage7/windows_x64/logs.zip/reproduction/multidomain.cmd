@echo off
call cbuild_dependency_stage4\runtime_prefix.cmd
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/test_output_keywords.py --engine exec/engine_win64.exe --output cbuild_dependency_stage7/native-output-dp-final --baseline cbuild_dependency_stage5/native-outputs-final
if errorlevel 1 exit /b 1
python cbuild_dependency_stage7/capture_old_multidomain.py
exit /b %errorlevel%
