import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import yaml

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'cbuild_dependency_stage7'

def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, text=True, check=False)

# Fix only newly introduced whitespace identified by Git, preserving source control characters.
issues = git('diff', '--check').stdout
fixed = 0
for name, number in re.findall(r'^(.+):(\d+): trailing whitespace\.$', issues, re.M):
    path = ROOT / name
    lines = path.read_bytes().split(b'\n')
    index = int(number) - 1
    lines[index] = re.sub(rb'[ \t]+(?=\r?$)', b'', lines[index])
    path.write_bytes(b'\n'.join(lines))
    fixed += 1
remaining = git('diff', '--check')
assert remaining.returncode == 0, remaining.stdout

changed = git('diff', '--name-only', '--diff-filter=ACMRT').stdout.splitlines()
changed += git('ls-files', '--others', '--exclude-standard').stdout.splitlines()
py_count = 0
yaml_count = 0
for name in sorted(set(changed)):
    path = ROOT / name
    if not path.is_file():
        continue
    if path.suffix == '.py':
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=name)
        py_count += 1
    if name.startswith('.github/workflows/') and path.suffix in ('.yml', '.yaml'):
        yaml.safe_load(path.read_text(encoding='utf-8-sig'))
        yaml_count += 1

sdk = re.compile(r'h3d(?:reader|writer)\.(?:dll|so)|libh3d(?:reader|writer)|hm_reader\.(?:dll|so)|Hyper3D|\b(?:c_h3d\w*|genh3d\w*|h3d_\w*)', re.I)
dumpbin = Path('C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/dumpbin.exe')
if not dumpbin.is_file():
    dumpbin = sorted(Path('C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Tools/MSVC').glob('*/bin/Hostx64/x64/dumpbin.exe'))[-1]
binary_records = []
for name in ('starter_win64.exe', 'engine_win64.exe', 'engine_win64_impi.exe', 'open_reader_win64.dll', 'starter_win64_sp.exe', 'engine_win64_sp.exe', 'engine_win64_impi_sp.exe'):
    path = ROOT / 'exec' / name
    data = path.read_bytes()
    dll_names = (b'h3dreader.dll', b'h3dwriter.dll', b'libh3dreader', b'libh3dwriter', b'hm_reader.dll', b'libhm_reader')
    found = [value.decode() for value in dll_names if value in data.lower() or value.decode().encode('utf-16le') in data.lower()]
    assert not found, (name, found)
    sections = []
    for option in ('/dependents', '/imports', '/exports'):
        run = subprocess.run([str(dumpbin), option, str(path)], capture_output=True, text=True, errors='replace')
        assert run.returncode == 0, run.stderr
        assert not sdk.search(run.stdout), (name, sdk.search(run.stdout).group())
        sections.append(run.stdout)
    (OUT / (name + '.pe.log')).write_text('\n'.join(sections), encoding='utf-8')
    binary_records.append({'path': 'exec/' + name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'sdk_library_names_absent': True, 'sdk_imports_exports_absent': True})

graphs = []
for folder in ('cbuild_dependency_stage6/clean-starter', 'engine/cbuild_engine_win64_ninja', 'engine/cbuild_engine_win64_impi_ninja', 'cbuild_dependency_stage7/starter-sp', 'cbuild_dependency_stage7/engine-sp', 'cbuild_dependency_stage7/engine-sp-impi'):
    path = ROOT / folder / 'compile_commands.json'
    commands = json.loads(path.read_text(encoding='utf-8'))
    forbidden = re.compile(r'(?:extlib|output)[/\\]+h3d[/\\]|h3dpublic|h3d_(?:inc_)?mod\.', re.I)
    assert not forbidden.search(json.dumps(commands)), folder
    graphs.append({'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'compilation_units': len(commands), 'sdk_sources_and_include_paths_absent': True})

report = {'status': 'passed', 'whitespace_lines_fixed': fixed, 'diff_check_passed': True, 'changed_python_files_parsed': py_count, 'changed_workflows_parsed': yaml_count, 'binaries': binary_records, 'build_graphs': graphs, 'limit': 'PE import/export and embedded SDK library-name inspection; no loaded-module snapshot or package/cache absence assertion. Package/cache/payload evidence is recorded separately; this audit covers Windows DP/SP SMP/MPI.'}
(OUT / 'binary_audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'passed', 'whitespace_lines_fixed': fixed, 'python_files_parsed': py_count, 'workflows_parsed': yaml_count, 'binaries': len(binary_records), 'build_graphs': len(graphs)}))
