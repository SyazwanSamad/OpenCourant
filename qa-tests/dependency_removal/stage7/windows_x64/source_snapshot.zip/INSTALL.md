# How to run OpenCourant

OpenCourant is made of:

* OpenCourant Starter that checks the model and splits the mesh
* OpenCourant Engine that runs the simulation in parallel
* Few [libraries](https://github.com/OpenCourant/OpenCourant/tree/main/extlib)
* A set of [configuration files](https://github.com/OpenCourant/OpenCourant/tree/main/hm_cfg_files) that describes the input

## Table of Contents

**Prerequisites**

* [Environment variables settings under Linux](#environment-variables-settings-under-linux)
* [Environment variables settings under Windows cmd shell](#environment-variables-settings-under-windows-cmd-shell)
* [Environment variables settings under Windows cygwin shell](#environment-variables-settings-under-windows-cygwin-shell)
 
**Running OpenCourant**

* [Running OpenCourant without MPI (OpenMP only)](#running-openradioss-without-mpi)
* [Running OpenCourant with MPI+OpenMP](#running-openradioss-with-mpi-and-openmp)
    * [Under Linux](#under-linux)
    * [Under Windows in cmd.exe shell](#under-windows-in-cmd-shell)
    * [Running OpenCourant container using Apptainer under Linux](#running-openradioss-container-using-apptainer-under-linux)
    * [Running OpenCourant container without MPI (OpenMP only)](#running-openradioss-container-without-mpi) 
* [Running OpenCourant test suite from the source code](#running-openradioss-test-suite-from-the-source-code)
* [Debugging OpenCourant with Visual Studio](./doc/Visual_Studio_Debugger.md)


## Prerequisites

Download and [build OpenCourant](https://github.com/OpenCourant/OpenCourant/blob/main/HOWTO.md), or download the [binaries](https://github.com/OpenCourant/OpenCourant/releases)

The current source build uses OpenReader and native result outputs. H3D requests
fail explicitly; see [Stage 5 behavior and validation](qa-tests/dependency_removal/STAGE5.md).
Delivery changes and dependency-archive publication evidence are recorded in
[Stage 6](qa-tests/dependency_removal/STAGE6.md). Packages ship OpenReader next
to Starter, the CFG/message tree, retained dependency notices, and the extlib pin
under `licenses/EXTLIB_VERSION.json`.

[Stage 7 Windows validation](qa-tests/dependency_removal/STAGE7.md) records the
current SP/DP regression failures and release blockers. Linux/ARM verification
is deferred at the user's request; no solver release is approved by these checks.

### Environment variables settings under Linux

Set the following environment variables:

        export OPENCOURANT_PATH=[Path to OpenCourant root directory]
        export RAD_CFG_PATH=$OPENCOURANT_PATH/hm_cfg_files
        export OMP_STACKSIZE=400m
        export LD_LIBRARY_PATH=$OPENCOURANT_PATH/exec:$OPENCOURANT_PATH/extlib/runtime/linux64:$LD_LIBRARY_PATH

### Environment variables settings under Windows cmd shell

Set the following environment variables:

        set OPENCOURANT_PATH=[Path to OpenCourant root directory / Windows Style]
        set RAD_CFG_PATH=%OPENCOURANT_PATH%\hm_cfg_files
        set KMP_STACKSIZE=400m
        set PATH=%OPENCOURANT_PATH%\exec;%PATH%

* If OpenCourant was downloaded from GitHub Releases, add Intel Runtime libraries shipped in the Package to PATH:

        set PATH=%OPENCOURANT_PATH%\extlib\intelOneAPI_runtime\win64;%PATH%

*  If OpenCourant was built from the Source code, use the Intel Runtime from the used compiler.
   The Intel oneAPI compiler installed and used for building the binaries could be more recent than the one used for building the Releases.
   In this case the Runtimes may not be compatible.

   In a typical installation, OneAPI variables are loaded with following command : 

        call "C:\Program Files (x86)\Intel\oneAPI\setvars.bat" intel64 vs2019

### Environment variables settings under Windows Cygwin shell

* If OpenCourant was built from source code, load the Intel oneAPI variables prior to launch Cygwin. This will load the appropriate
  Runtime libraries.

        call "C:\Program Files (x86)\Intel\oneAPI\setvars.bat" intel64 vs2019
        chdir C:\cygwin64\bin
        bash --login -i

* If OpenCourant was downloaded from GitHub Releases, 
 
Cygwin is translating `PATH` variable into DOS path to execute OpenCourant, but not other variables.
Considering that the OpenCourant directory is placed in `C:\OpenCourant`, then variables should be:

        export OPENCOURANT_PATH=/cygdrive/c/OpenCourant
        export PATH=$OPENCOURANT_PATH/exec:$PATH
        export PATH=$OPENCOURANT_PATH/extlib/intelOneAPI_runtime/win64:$PATH
        export RAD_CFG_PATH=c:/OpenCourant/hm_cfg_files
        export KMP_STACKSIZE=400m


Note that `RAD_CFG_PATH` starts with `c:` unlike `PATH`, which starts with `/cygdrive/c`.


## Running OpenCourant


### Running OpenCourant without MPI

* Define number of OpenMP threads

   * **Under Linux and Windows Cygwin**

         export OMP_NUM_THREADS=[N]

   * **Under Windows**

         set OMP_NUM_THREADS=[N]

* Run OpenCourant Starter and Engine from the directory that contains the binaries

   * **Under Linux**

         ./starter_linux64_gf -i [Starter input file] -np 1
         ./engine_linux64_gf -i [Engine input file]

  * **Under Windows**

        starter_win64.exe -i [Starter input file] -np 1
        engine_win64.exe  -i [Engine input file]


### Running OpenCourant with MPI and OpenMP

#### Under Linux 

* Set up environment variables, assuming that OpenMPI is installed in `/opt/openmpi`

        export LD_LIBRARY_PATH=/opt/openmpi/lib:$LD_LIBRARY_PATH
        export PATH=/opt/openmpi/bin:$PATH

* Run OpenCourant with P MPI processes and N threads per domain from the directory that contains the binaries

        export OMP_STACKSIZE=400m
        export OMP_NUM_THREADS=[N]
        ./starter_linux64_gf -i [Starter input file] -np [P]
        mpiexec -n [P]  --map-by socket:PE=$OMP_NUM_THREADS --bind-to core ./engine_linux64_gf_ompi -i [Engine input file]


#### Under Windows in cmd shell

* Release packages bundle the Intel MPI runtime in
  `extlib\intelOneAPI_runtime\win64` (already on `PATH` after the
  environment setup above). Single-node runs need no further setup:

        set OMP_NUM_THREADS=[N]
        starter_win64.exe -i [Starter input file] -np [P]
        mpiexec -localonly -np [P] engine_win64_impi.exe -i [Engine input file]

* For the service-based launcher, register the hydra service once as
  administrator and use `-delegate`:

        hydra_service.exe -install
        mpiexec -delegate -np [P] engine_win64_impi.exe -i [Engine input file]

* Multi-node clusters, and builds made from source, should install Intel
  oneAPI MPI and load its variables instead:

        call [Path to Intel OneAPI]\env\vars.bat

### Running the OpenCourant container under Linux

Prebuilt multi-arch (x86_64 and arm64) solver containers are published with
every stable release:

        ghcr.io/opencourant/opencourant:latest
        ghcr.io/opencourant/opencourant:latest-YYYYMMDD

The executables are on `PATH` inside the container under convenience names
(`starter`, `engine`, `engine_ompi`, plus `_sp` single-precision variants),
the OpenMPI runtime is included, and all environment variables are preset.

#### With Docker or Podman

* Run Starter and Engine from the directory that contains the input file

        docker run --rm -v $PWD:/work -e OMP_NUM_THREADS=[N] \
            ghcr.io/opencourant/opencourant starter -i [Starter input file] -np 1
        docker run --rm -v $PWD:/work -e OMP_NUM_THREADS=[N] \
            ghcr.io/opencourant/opencourant engine -i [Engine input file]

* Run with P MPI processes and N threads per domain

        docker run --rm -v $PWD:/work -e OMP_NUM_THREADS=[N] \
            ghcr.io/opencourant/opencourant starter -i [Starter input file] -np [P]
        docker run --rm -v $PWD:/work -e OMP_NUM_THREADS=[N] \
            ghcr.io/opencourant/opencourant mpiexec -np [P] engine_ompi -i [Engine input file]

#### With Apptainer

* Every stable release attaches ready-made SIF images
  (`OpenCourant_linux64.sif`, `OpenCourant_linuxa64.sif`) on
  [the releases page](https://github.com/OpenCourant/OpenCourant/releases).
  Download one, or pull the container image instead (build from
  `Apptainer/opencourant.def`, or compile from source with
  `Apptainer/opencourant_build.def`):

        apptainer pull opencourant.sif docker://ghcr.io/opencourant/opencourant:latest

* Run without MPI from the directory that contains the input file

        export OMP_NUM_THREADS=[N]
        apptainer exec opencourant.sif starter -i [Starter input file] -np 1
        apptainer exec opencourant.sif engine -i [Engine input file]

* Run with P MPI processes and N threads per domain

        export OMP_NUM_THREADS=[N]
        apptainer exec opencourant.sif starter -i [Starter input file] -np [P]
        apptainer exec opencourant.sif mpiexec --map-by socket:PE=$OMP_NUM_THREADS --bind-to core -np [P] engine_ompi -i [Engine input file]

## Running OpenCourant test suite from the source code

### Under Linux

* Go to the `qa_test/scripts` directory

        cd $OPENCOURANT_PATH/qa-tests/scripts

#### Running without MPI (OpenMP only)

        perl ./or_qa_script ../../exec/engine_linux64_gf 1.0

#### Running with MPI (MPI+OpenMP)

* Set up environment variables, assuming that OpenMPI is installed in `/opt/openmpi`

        export LD_LIBRARY_PATH=/opt/openmpi/lib:$LD_LIBRARY_PATH
        export PATH=/opt/openmpi/bin:$PATH

* Run the test suite with P MPI processes, and N threads per MPI process

        export OMP_NUM_THREADS=[N]
        perl ./or_qa_script ../../exec/engine_linux64_gf_ompi --exec_script_args="mpiexec -np [P]"  1.0

### Under Windows

The QA test case can be executed under Cygwin.
Set the variables like running under Cygwin.

* Go to the `qa_test/scripts` directory

        cd $OPENCOURANT_PATH/qa-tests/scripts

#### Running without MPI

        perl ./or_qa_script ../../exec/engine_win64.exe 1.0


#### Running with MPI (MPI+OpenMP)

* Set up environment variables assuming Intel OneAPI / MPI is installed & variables loaded.

* Run the test suite with P MPI processes, and N threads per MPI process

        export OMP_NUM_THREADS=[N]
        perl ./or_qa_script ../../exec/engine_win64_impi.exe --exec_script_args="mpiexec -delegate -np [P]"  1.0
