@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\compiler\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\mkl\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%
call "C:\Program Files (x86)\Intel\oneAPI\mpi\2021.16\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set RAD_PYTHON_PATH=C:\Python\Python311\python311.dll
set I_MPI_FABRICS=shm
python qa-tests/reader/rigid_parts/build_integration.py --starter-build cbuild_dependency_stage3/clean-starter --output cbuild_dependency_stage5/binaries
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/capture_baseline.py --binaries cbuild_dependency_stage5/binaries --starter-build cbuild_dependency_stage3/clean-starter --output cbuild_dependency_stage5/regression
if errorlevel 1 exit /b 1
python qa-tests/dependency_removal/compare_decks.py --binaries cbuild_dependency_stage5/binaries --output cbuild_dependency_stage5/native-decks
exit /b %errorlevel%
