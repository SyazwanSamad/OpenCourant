@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\compiler\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\mkl\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%
call "C:\Program Files (x86)\Intel\oneAPI\mpi\2021.16\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set RAD_PYTHON_PATH=C:\Python\Python311\python311.dll
set I_MPI_FABRICS=shm

python qa-tests/dependency_removal/test_native_mpi.py --engine cbuild_dependency_stage5/reference_runtime/engine_win64_impi.exe --starter cbuild_dependency_stage5/reference_runtime/starter_win64.exe --output cbuild_dependency_stage5/native-mpi-pressure-before
if errorlevel 1 exit /b 1
exit /b 0
