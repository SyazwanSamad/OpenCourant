@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\compiler\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
call "C:\Program Files (x86)\Intel\oneAPI\mkl\2025.2\env\vars.bat" >nul
if errorlevel 1 exit /b 1
set PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;%PATH%
cmake -S starter -B cbuild_dependency_stage3/clean-starter
if errorlevel 1 exit /b 1
cmake --build cbuild_dependency_stage3/clean-starter --parallel 1
exit /b %errorlevel%


